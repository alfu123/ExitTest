public class IMPQUESTIONS {

    //1. JAVA memory management: stack vs heap:   https://www.youtube.com/watch?v=450maTzSIvA

    //2. jvm, jdk, jre : https://www.youtube.com/watch?v=RYd_hagCiVk

}
