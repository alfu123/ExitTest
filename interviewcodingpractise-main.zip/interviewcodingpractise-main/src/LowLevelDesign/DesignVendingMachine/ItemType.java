package LowLevelDesign.DesignVendingMachine;

public enum ItemType {

    COKE,
    PEPSI,
    JUICE,
    SODA;
}
