package LowLevelDesign.DesignOrderManagementSystem;

public enum OrderStatus {

    DELIVERED,
    CANCELLED,
    RETURNED,
    UNDELIVERED;
}
