package LowLevelDesign.DesignOrderManagementSystem;

public class Product {

    int productId;
    String productName;
}
