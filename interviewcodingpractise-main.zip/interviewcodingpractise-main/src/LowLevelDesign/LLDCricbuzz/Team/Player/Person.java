package LowLevelDesign.LLDCricbuzz.Team.Player;

public class Person {
    public String name;
    public int age;
    public String address;
}
