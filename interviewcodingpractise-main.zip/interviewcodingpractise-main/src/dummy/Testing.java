package dummy;

import java.util.Comparator;
import java.util.PriorityQueue;

public class Testing extends Test2 {

    @Override
    public void method1() {

    }
}


