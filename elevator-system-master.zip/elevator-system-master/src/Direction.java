public enum Direction {
    STOP,
    UP,
    DOWN
}
