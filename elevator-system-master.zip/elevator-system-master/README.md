# Elevator System

Designing a single (will be extending to multiple server and multiple buildings) elevator system to serve request like to server request of floor and calling and waiting in queue.

I am using State and Singleton Pattern in the system and Java as coding language.

The data will be in main memory.