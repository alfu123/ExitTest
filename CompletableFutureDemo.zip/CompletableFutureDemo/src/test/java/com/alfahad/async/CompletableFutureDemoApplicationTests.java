package com.alfahad.async;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CompletableFutureDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
